﻿using GYM_project.context;
using GYM_project.Entity;
using GYM_project.Reposaterie.InterFaces;
using Microsoft.EntityFrameworkCore;

namespace GYM_project.Reposaterie.Classes
{
    public class PlanRepository : IPlanRepository
    {
        private GymDbContext dbContext = new GymDbContext();
        public async Task<IEnumerable<Plan>> GetAllAsync(CancellationToken ct = default)
        {
            return await dbContext.Plans.AsNoTracking().ToListAsync(ct);
        }
    }
}
