﻿using GYM_project.context;
using GYM_project.Reposaterie.Classes;
using GYM_project.Reposaterie.InterFaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GYM_project.Controllers
{
    public class PlanController : Controller
    {
        private IPlanRepository planRepository = new PlanRepository();
        public async Task<IActionResult> Index()
        {
            var Plans = await planRepository.GetAllAsync();   
            return View(Plans);
        }
    }
}
